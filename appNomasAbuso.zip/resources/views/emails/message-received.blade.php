<!DOCTYPE html>
<html>
<head>
  <title>Mensaje Recibido</title>
</head>
<body>
  <p>Recibiste un mensaje de: {{ $msg['name']}} - {{$msg['email']}} </p>
  <p><strong>Localidad:</strong> {{$msg['subject']}} </p>
  <p><strong>Caso:</strong> {{$msg['content']}} </p>

</body>
</html>