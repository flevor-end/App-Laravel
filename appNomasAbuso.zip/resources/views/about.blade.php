@extends('layout')

@section('title', 'About')

@section('content')
  <h1>About</>
@endsection