Mensaje personalido para el error 404 <br>
<a href="/">volver al inicio</a>