# Prueba desarrollo web con laravel

![Captura de portafolio](.readme-static/captura.png)

Prueba laravel que utiliza la Laragon como servidor para mostrar la prueba con sus instrucciones. Algunas de las features que tiene son:

-   laragon

## Scripts

-   `npm install` para instalar las dependencias
-   `npm run dev` para entorno de desarrollo
-   `npm run prod` para producción

## Licencia

MIT
