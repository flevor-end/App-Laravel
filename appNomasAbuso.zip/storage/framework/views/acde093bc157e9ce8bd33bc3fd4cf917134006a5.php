

<?php $__env->startSection('title', 'Portfolio'); ?>

<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="d-flex justify-content-between align-items-center">
      <h1 class="display-4 mb-0"><?php echo app('translator')->get('Projects'); ?></h1>
      
      <?php if(auth()->guard()->check()): ?>
      <a class="btn btn-primary" 
        href="<?php echo e(route('projects.create')); ?>"
        >Crear Proyecto</a>
      <?php endif; ?>
    </div>
    <hr>
    <p class="lead text-secondary">Para poder editar los proyectos debe registrarse.
      </p>
    <ul class="list-group">    
      <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <li class="list-group-item border-0 mb-3 shadow-sm">
          <a class="text-secondary d-flex justify-content-between align-items-center"
            href="<?php echo e(route('projects.show', $project)); ?>"
            >
            <span class="font-weight-bold"><?php echo e($project->title); ?></span>
            <span class="text-black-50"><?php echo e($project->created_at->format('d/m/y')); ?></span>
          </a>
        </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <li class="list-group-item border-0 mb-3 shadow-sm">
          No hay proyectos para mostrar
        </li>
      <?php endif; ?>
      <?php echo e($projects->links()); ?>

    </ul>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\app\resources\views/projects/index.blade.php ENDPATH**/ ?>