<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <title><?php echo $__env->yieldContent('#title'); ?></title>
  <link rel="stylesheet" href="/css/app.css">
  <script src="/js/app.js" defer></script>

</head>
<body>
  <div id="app" class="d-flex flex-column h-screen 
  justify-content-between">
    <header><?php echo $__env->make('partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php if(auth()->guard()->check()): ?>
  <?php echo e(auth()->user()->name); ?>

  <?php endif; ?>
    </header>
  
    <main class=""><?php echo $__env->yieldContent('content'); ?></main>
    
    <footer  class="bg-dark text-center text-white-50 py-3 shadow">
      <?php echo e(config('app.name')); ?> | Copyright @ <?php echo e(date('y')); ?>

    </footer>
  </div>
  </body>
</html><?php /**PATH C:\laragon\www\app\resources\views/layout.blade.php ENDPATH**/ ?>