<!DOCTYPE html>
<html>
<head>
  <title>Mensaje Recibido</title>
</head>
<body>
  <p>Recibiste un mensaje de: <?php echo e($msg['name']); ?> - <?php echo e($msg['email']); ?> </p>
  <p><strong>Localidad:</strong> <?php echo e($msg['subject']); ?> </p>
  <p><strong>Caso:</strong> <?php echo e($msg['content']); ?> </p>

</body>
</html><?php /**PATH C:\laragon\www\app\resources\views/emails/message-received.blade.php ENDPATH**/ ?>