Mensaje personalido para el error 404 <br>
<a href="/">volver al inicio</a><?php /**PATH C:\laragon\www\app\resources\views/errors/404.blade.php ENDPATH**/ ?>