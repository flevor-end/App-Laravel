

<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
<div class="hero">
        <div class="container">
          <h1 class="display-4 text-white"
          >#NoMasAbusos</h1>
        </div>
      </div>
<section class="section">
  <div class="row">
    <div class="col-12">
      <div class="container text-center">
      <p class="copy">En esta página podrá direccionar su queja a las entidades que 
        le ayudarán a darle solución a su problemática <br>Por Favor Seleccione la entidad que le generó la problemática</p>
      </div>
      <div class="section__grid">       
        <div class="section__item">
          
          <a class="btn btn-lg btn-block" 
          href="<?php echo e(route('codensa')); ?>">
          <img src="../img/energia.png" alt="" />
          <p>#RespondaCodensa</p></a>
        </div>
        <div class="section__item">
          
          <a class="btn btn-lg btn-block" 
          href="<?php echo e(route('vanti')); ?>">
          <img src="../img/vanti.png" alt="" />
          <p>#RespondaVanti</p></a>
        </div>
        <div class="section__item">
          <a class="btn btn-lg btn-block" 
          href="<?php echo e(route('agua')); ?>">
          <img src="../img/agua.png" alt="" />
          <p>#RespondaAcueducto</p></a>
        </div>
        <!-- <a class="btn btn-lg btn-block" 
        href="<?php echo e(route('projects.index')); ?>">casos</a> -->
      </div>
  </div>
</div>
  



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\app\resources\views/home.blade.php ENDPATH**/ ?>