  <?php echo csrf_field(); ?>
  <div class="form-group">
    <label for="title">Titulo del Proyecto</label>
      <input class="form-control border-0 bg-light shadow-sm" 
      id="title" 
      type="text" 
      name="title" 
      value="<?php echo e(old('title', $project->title)); ?>">  
  </div>

  <div class="form-group">
    <label for="url">Url del Proyecto</label>
    <input class="form-control border-0 bg-light shadow-sm" 
      id="title"
      type="text" 
      name="url" 
      value="<?php echo e(old('url', $project->url)); ?>">  
  </div>

  <div class="form-group">
    <label>Descripcion del Proyecto</label>
    <textarea class="form-control border-0 bg-light shadow-sm" 
      name="description"
      ><?php echo e(old('description', $project->description)); ?></textarea>
  </div>
 
    <button class="btn btn-primary btn-lg btn-block">
    <?php echo e($btnText); ?></button>
    <a class="btn btn-link btn-block" href="<?php echo e(route('projects.index')); ?>"
        >Cancelar</a>
<?php /**PATH C:\laragon\www\app\resources\views/projects/_form.blade.php ENDPATH**/ ?>