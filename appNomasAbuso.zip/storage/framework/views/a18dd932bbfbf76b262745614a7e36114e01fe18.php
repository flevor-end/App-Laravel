<nav class="navbar navbar-light navbar-expand-lg bg-white shadow-sm justify-content-space-bet">
    
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
            <?php echo e(config('app.name')); ?>

        </a>
        <button class="navbar-toggler" type="button" 
            data-toggle="collapse" 
            data-target="#navbarSupportedContent" 
            aria-controls="navbarSupportedContent" 
            aria-expanded="false" 
            aria-label="<?php echo e(__('Toggle navigation')); ?>">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
            <ul class="nav nav-pills">
                <li class="nav-item">
                <a class="nav-link <?php echo e(setActive('home')); ?>" href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('Home'); ?></a>
                </li>
                <!-- <li class="nav-item">
                <a class="nav-link <?php echo e(setActive('about')); ?>" href="<?php echo e(route('about')); ?>"><?php echo app('translator')->get('About'); ?></a>
                </li> -->
                <!-- <li class="nav-item">
                <a class="nav-link <?php echo e(setActive('projects.*')); ?>" href="<?php echo e(route('projects.index')); ?>"><?php echo app('translator')->get('Projects'); ?></a>
                </li> -->
                <li class="nav-item">
                <a class="nav-link <?php echo e(setActive('contact')); ?>" href="<?php echo e(route('codensa')); ?>"><?php echo app('translator')->get('Codensa'); ?></a>

                </li>
                <li class="nav-item"><a class="nav-link <?php echo e(setActive('contact')); ?>" href="<?php echo e(route('vanti')); ?>"><?php echo app('translator')->get('Vanti'); ?></a></li>
                <li class="nav-item"><a class="nav-link <?php echo e(setActive('contact')); ?>" href="<?php echo e(route('agua')); ?>"><?php echo app('translator')->get('Acueducto'); ?></a></li>
                <?php if(auth()->guard()->guest()): ?>
                <li class="nav-item"><a class="nav-link <?php echo e(setActive('login')); ?>" href="<?php echo e(route('login')); ?>"><?php echo app('translator')->get('Login'); ?></a></li>
                <li class="nav-item"><a class="nav-link <?php echo e(setActive('register')); ?>" href="<?php echo e(route('register')); ?>"><?php echo app('translator')->get('Registrarse'); ?></a></li>

                <?php else: ?>
                    <li class="nav-item"><a class="nav-link" href="#" onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();">
                        Cerrar Sesión
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
    
  </nav>

  <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form><?php /**PATH C:\laragon\www\app\resources\views/partials/nav.blade.php ENDPATH**/ ?>